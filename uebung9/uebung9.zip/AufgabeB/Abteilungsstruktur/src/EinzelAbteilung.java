public class EinzelAbteilung extends Abteilung {
    public EinzelAbteilung(String name) {
        super(name);
    }
}
